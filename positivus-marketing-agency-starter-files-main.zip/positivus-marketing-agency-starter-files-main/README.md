# positivus-marketing-agency-reactjs
![positivus-marketing-agency-reactjs](/src/assets/github-cover.png)

## How to run this project:

### For Frontend 
Follow the below steps to run the project: 
- Firstly clone or unzip the project folder.
* Go to the folder directory(folder name) by using the following command ``` cd positivus-marketing-agency-reactjs ```.
+ Then run `` npm install `` commend to install node dependencies.
- Finally, to run the project, use ``npm run dev`` command.
