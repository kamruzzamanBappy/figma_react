
const testimonialsData = [
    { id: 1, text: "This service is fantastic! My business has seen remarkable growth since we started using it.", author: "John Doe" },
    { id: 2, text: "Excellent customer support and results. Highly recommend this team to anyone looking to enhance their online presence.", author: "Jane Smith" },
    { id: 3, text: "A game-changer for our marketing strategy. The results were beyond our expectations!", author: "Alice Johnson" },
    { id: 4, text: "Professional, reliable, and effective. This team knows what they're doing!", author: "Bob Brown" },
];

export default testimonialsData;