
import './App.css'

function App() {


  return (
    <div className='font-primary overflow-hidden'>
      <h1>Positivus Marketing Agency Stater Files</h1>
    </div>
  )
}

export default App
